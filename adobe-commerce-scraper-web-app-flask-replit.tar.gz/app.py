import os
import logging
from flask import Flask, render_template, request, jsonify
from datetime import datetime
from scraper import get_bulletins, parse_date

logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "dev-secret-key")

# Default URLs for Adobe Commerce security scraping
DEFAULT_URLS = [
    "https://helpx.adobe.com/security/products/magento.html",
    "https://helpx.adobe.com/security.html",
    "https://experienceleague.adobe.com/en/docs/commerce-operations/release/notes/security-patches/overview",
    "https://devdocs.magento.com/guides/v2.4/release-notes/bk-release-notes.html",
    "https://support.magento.com/hc/en-us/sections/360010506631-Security-patches",
    "https://magento.com/security/patches",
    "https://experienceleague.adobe.com/docs/commerce-operations/installation-guide/tutorials/extensions.html"
]

@app.route('/')
def index():
    """Main page with scraper interface."""
    return render_template('index.html', default_urls=DEFAULT_URLS)

@app.route('/scrape', methods=['POST'])
def scrape():
    """API endpoint to perform scraping based on user input."""
    try:
        data = request.get_json()
        
        # Parse input data
        from_date_str = data.get('from_date')
        to_date_str = data.get('to_date')
        enabled_urls = data.get('urls', [])
        
        # Validate dates
        try:
            from_date = datetime.strptime(from_date_str, '%Y-%m-%d')
            to_date = datetime.strptime(to_date_str, '%Y-%m-%d')
        except ValueError as e:
            return jsonify({'error': f'Invalid date format: {str(e)}'}), 400
        
        if from_date > to_date:
            return jsonify({'error': 'From date must be before or equal to to date'}), 400
        
        if not enabled_urls:
            return jsonify({'error': 'At least one URL must be selected'}), 400
        
        # Collect results from all enabled URLs
        all_bulletins = []
        url_results = {}
        
        for url in enabled_urls:
            try:
                app.logger.info(f"Scraping URL: {url}")
                bulletins = get_bulletins(url)
                url_results[url] = {
                    'status': 'success',
                    'count': len(bulletins),
                    'error': None
                }
                all_bulletins.extend(bulletins)
            except Exception as e:
                app.logger.error(f"Failed to scrape {url}: {str(e)}")
                url_results[url] = {
                    'status': 'error',
                    'count': 0,
                    'error': str(e)
                }
        
        # Filter by date range and deduplicate
        seen = set()
        filtered = []
        for b in all_bulletins:
            if not b["date"]:
                continue
            if from_date <= b["date"] <= to_date:
                key = (b["title"], b["date"], b["url"])
                if key not in seen:
                    seen.add(key)
                    # Convert date to string for JSON serialization
                    bulletin_copy = b.copy()
                    bulletin_copy["date"] = b["date"].strftime("%Y-%m-%d")
                    filtered.append(bulletin_copy)
        
        # Sort by date descending
        filtered.sort(key=lambda x: datetime.strptime(x["date"], "%Y-%m-%d"), reverse=True)
        
        return jsonify({
            'success': True,
            'bulletins': filtered,
            'url_results': url_results,
            'total_found': len(filtered),
            'date_range': {
                'from': from_date_str,
                'to': to_date_str
            }
        })
        
    except Exception as e:
        app.logger.error(f"Scraping error: {str(e)}")
        return jsonify({'error': f'Scraping failed: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
