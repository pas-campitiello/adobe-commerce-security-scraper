class SecurityScraper {
    constructor() {
        this.initializeEventListeners();
        this.currentResults = [];
        this.sortDirection = {};
    }

    initializeEventListeners() {
        document.getElementById('scraperForm').addEventListener('submit', this.handleSubmit.bind(this));
        document.getElementById('exportBtn').addEventListener('click', this.exportResults.bind(this));
        
        // Add sorting event listeners
        document.querySelectorAll('.sortable').forEach(header => {
            header.addEventListener('click', this.handleSort.bind(this));
        });
    }

    async handleSubmit(e) {
        e.preventDefault();
        
        const fromDate = document.getElementById('fromDate').value;
        const toDate = document.getElementById('toDate').value;
        const selectedUrls = Array.from(document.querySelectorAll('.url-checkbox:checked'))
            .map(checkbox => checkbox.value);

        if (!fromDate || !toDate) {
            this.showError('Please select both from and to dates.');
            return;
        }

        if (selectedUrls.length === 0) {
            this.showError('Please select at least one URL to scrape.');
            return;
        }

        this.showLoading();
        
        try {
            const response = await fetch('/scrape', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    from_date: fromDate,
                    to_date: toDate,
                    urls: selectedUrls
                })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.error || 'Scraping failed');
            }

            this.displayResults(data);
        } catch (error) {
            this.showError(error.message);
        }
    }

    showLoading() {
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('errorState').style.display = 'none';
        document.getElementById('resultsTable').style.display = 'none';
        document.getElementById('urlStatus').style.display = 'none';
        document.getElementById('loadingState').style.display = 'block';
        
        // Disable the scrape button
        const scrapeBtn = document.getElementById('scrapeBtn');
        scrapeBtn.disabled = true;
        scrapeBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-2"></i>Scraping...';
    }

    showError(message) {
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('resultsTable').style.display = 'none';
        document.getElementById('urlStatus').style.display = 'none';
        
        document.getElementById('errorMessage').textContent = message;
        document.getElementById('errorState').style.display = 'block';
        
        this.resetScrapeButton();
    }

    displayResults(data) {
        document.getElementById('loadingState').style.display = 'none';
        document.getElementById('emptyState').style.display = 'none';
        document.getElementById('errorState').style.display = 'none';
        
        this.currentResults = data.bulletins;
        
        // Update summary
        const summary = document.getElementById('resultsSummary');
        summary.textContent = `${data.total_found} bulletins found (${data.date_range.from} to ${data.date_range.to})`;
        
        // Show URL status
        this.displayUrlStatus(data.url_results);
        
        // Display results table
        this.displayTable(data.bulletins);
        
        this.resetScrapeButton();
    }

    displayUrlStatus(urlResults) {
        const statusContainer = document.getElementById('urlStatusList');
        statusContainer.innerHTML = '';
        
        Object.entries(urlResults).forEach(([url, result]) => {
            const statusDiv = document.createElement('div');
            statusDiv.className = `url-status-item url-status-${result.status}`;
            
            const icon = result.status === 'success' ? 
                '<i class="fas fa-check-circle me-2"></i>' : 
                '<i class="fas fa-exclamation-triangle me-2"></i>';
            
            const message = result.status === 'success' ? 
                `${result.count} bulletins found` : 
                `Error: ${result.error}`;
            
            statusDiv.innerHTML = `
                ${icon}
                <small class="d-block text-break">${url}</small>
                <small>${message}</small>
            `;
            
            statusContainer.appendChild(statusDiv);
        });
        
        document.getElementById('urlStatus').style.display = 'block';
    }

    displayTable(bulletins) {
        const tbody = document.getElementById('resultsBody');
        tbody.innerHTML = '';
        
        if (bulletins.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="3" class="text-center text-muted py-4">
                        <i class="fas fa-inbox fa-2x mb-2 d-block"></i>
                        No security bulletins found for the selected date range.
                    </td>
                </tr>
            `;
        } else {
            bulletins.forEach(bulletin => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${bulletin.date}</td>
                    <td>${this.escapeHtml(bulletin.title)}</td>
                    <td>
                        <a href="${bulletin.url}" target="_blank" class="btn btn-outline-primary btn-sm">
                            <i class="fas fa-external-link-alt me-1"></i>
                            View
                        </a>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }
        
        document.getElementById('resultsTable').style.display = 'block';
    }

    handleSort(e) {
        const sortKey = e.currentTarget.dataset.sort;
        const currentDirection = this.sortDirection[sortKey] || 'asc';
        const newDirection = currentDirection === 'asc' ? 'desc' : 'asc';
        
        // Update sort direction
        this.sortDirection = {}; // Reset all
        this.sortDirection[sortKey] = newDirection;
        
        // Update UI
        document.querySelectorAll('.sortable').forEach(header => {
            header.classList.remove('sort-asc', 'sort-desc');
        });
        e.currentTarget.classList.add(`sort-${newDirection}`);
        
        // Sort data
        this.currentResults.sort((a, b) => {
            let aValue = a[sortKey];
            let bValue = b[sortKey];
            
            if (sortKey === 'date') {
                aValue = new Date(aValue);
                bValue = new Date(bValue);
            }
            
            if (aValue < bValue) return newDirection === 'asc' ? -1 : 1;
            if (aValue > bValue) return newDirection === 'asc' ? 1 : -1;
            return 0;
        });
        
        // Re-render table
        this.displayTable(this.currentResults);
    }

    exportResults() {
        if (this.currentResults.length === 0) {
            alert('No results to export');
            return;
        }
        
        const csv = this.convertToCSV(this.currentResults);
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `adobe-commerce-security-bulletins-${new Date().toISOString().split('T')[0]}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    convertToCSV(data) {
        const headers = ['Date', 'Title', 'URL'];
        const rows = data.map(item => [
            item.date,
            `"${item.title.replace(/"/g, '""')}"`,
            item.url
        ]);
        
        return [headers, ...rows].map(row => row.join(',')).join('\n');
    }

    resetScrapeButton() {
        const scrapeBtn = document.getElementById('scrapeBtn');
        scrapeBtn.disabled = false;
        scrapeBtn.innerHTML = '<i class="fas fa-search me-2"></i>Start Scraping';
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new SecurityScraper();
});
