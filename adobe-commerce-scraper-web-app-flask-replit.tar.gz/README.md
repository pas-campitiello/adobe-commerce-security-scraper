# Adobe Commerce Security Bulletin Scraper

A Flask-based web application for scraping Adobe Commerce (Magento) security bulletins from multiple sources within specified date ranges.

## Features

- **Interactive Web Interface**: Clean, responsive Bootstrap design with dark theme
- **Date Range Selection**: Pick custom date ranges for targeted searches
- **Multiple Source Support**: Toggle between 7 different Adobe/Magento security sources
- **Real-time Results**: Live scraping with progress indicators and status updates
- **Sortable Results**: Click column headers to sort by date or title
- **Export Functionality**: Download results as CSV files
- **Error Handling**: Detailed status reporting for each source URL

## Installation

1. Install Python 3.11 and required dependencies:
```bash
pip install flask beautifulsoup4 requests gunicorn
```

2. Run the application:
```bash
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

3. Open your browser to `http://localhost:5000`

## Usage

1. **Set Date Range**: Use the date pickers to specify your search period
2. **Select Sources**: Check/uncheck the URLs you want to scrape
3. **Start Scraping**: Click "Start Scraping" to begin the search
4. **View Results**: Results appear in a sortable table with export options
5. **Export Data**: Click "Export Results" to download a CSV file

## File Structure

```
├── main.py          # Application entry point
├── app.py           # Flask routes and main logic
├── scraper.py       # Web scraping functionality
├── templates/
│   └── index.html   # Main web interface
├── static/
│   ├── script.js    # Frontend JavaScript
│   └── style.css    # Custom styling
└── README.md        # This file
```

## Target Sources

- Adobe Help Center Security Pages
- Experience League Documentation
- Magento DevDocs Release Notes
- Support Portal Security Patches
- Official Magento Security Pages

## Technical Details

- **Backend**: Flask with Gunicorn
- **Scraping**: BeautifulSoup4 + Requests
- **Frontend**: Bootstrap 5 + Vanilla JavaScript
- **Date Handling**: Multiple format parsing for various Adobe bulletin formats
- **Responsive Design**: Mobile-friendly interface

## License

Open source - modify and distribute freely.